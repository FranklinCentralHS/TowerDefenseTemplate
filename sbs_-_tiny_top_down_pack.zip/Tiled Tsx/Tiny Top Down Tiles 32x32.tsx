<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="Tiny Top Down Tiles" tilewidth="32" tileheight="32" tilecount="100" columns="10">
 <image source="../Tiny Top Down 32x32.png" trans="008080" width="320" height="320"/>
</tileset>
